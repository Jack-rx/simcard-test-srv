/* ═══════════════════════════════════════════════════════
   Remote Commander — Terminal JS
   ═══════════════════════════════════════════════════════ */

'use strict';

// ── DOM refs ────────────────────────────────────────────
const output    = document.getElementById('output');
const cmdInput  = document.getElementById('cmdInput');
const btnSend   = document.getElementById('btnSend');
const btnClear  = document.getElementById('btnClear');
const agentBadge = document.getElementById('agentBadge');
const agentText  = document.getElementById('agentText');
const cmdChips   = document.querySelectorAll('.cmd-chip');

// ── State ────────────────────────────────────────────────
const inputHistory  = [];
let   histIndex     = -1;
let   agentLastSeen = null;  // timestamp último poll exitoso

// ── Init ─────────────────────────────────────────────────
cmdInput.focus();
loadHistory();
startAgentHeartbeat();

// ── Event Listeners ──────────────────────────────────────
btnSend.addEventListener('click', sendCommand);
btnClear.addEventListener('click', clearOutput);

cmdInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') { sendCommand(); return; }

  // Navegar historial con flechas
  if (e.key === 'ArrowUp') {
    e.preventDefault();
    histIndex = Math.min(histIndex + 1, inputHistory.length - 1);
    cmdInput.value = inputHistory[histIndex] ?? '';
    moveCursorToEnd();
    return;
  }
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    histIndex = Math.max(histIndex - 1, -1);
    cmdInput.value = histIndex >= 0 ? inputHistory[histIndex] : '';
    moveCursorToEnd();
  }
});

// Chips de comandos rápidos
cmdChips.forEach(chip => {
  chip.addEventListener('click', () => {
    cmdInput.value = chip.dataset.cmd;
    cmdInput.focus();
    moveCursorToEnd();
  });
});

// ── Core: enviar comando ──────────────────────────────────
async function sendCommand() {
  const raw = cmdInput.value.trim();
  if (!raw) return;

  const [type, ...rest] = raw.split(' ');
  const arg = rest.join(' ');

  // Guardar en historial de input
  inputHistory.unshift(raw);
  histIndex = -1;
  cmdInput.value = '';

  // Crear card visual
  const card = createCard(type, arg);
  output.appendChild(card);
  scrollToBottom();

  try {
    const res  = await api.post('/api/commands', { type, arg });
    const data = await res.json();

    if (!res.ok) {
      setCardResult(card, null, data.error ?? 'Error desconocido', 'error');
      return;
    }

    updateCardBadge(card, 'pending');
    setCardWaiting(card, '▸ comando en cola — esperando ejecución en el dispositivo…');
    pollForResult(data.id, card);

  } catch (err) {
    setCardResult(card, null, `Error de red: ${err.message}`, 'error');
  }
}

// ── Polling: esperar resultado ────────────────────────────
async function pollForResult(cmdId, card, attempts = 0) {
  const MAX_ATTEMPTS = 45;  // ~90s
  if (attempts >= MAX_ATTEMPTS) {
    setCardResult(card, null, '⏱ Timeout: el dispositivo no respondió.', 'timeout');
    return;
  }

  try {
    const res  = await api.get(`/api/commands/${cmdId}`);
    const data = await res.json();

    if (data.status === 'done' || data.status === 'timeout') {
      setCardResult(card, data.status, data.result ?? '(sin respuesta)', data.status);
      return;
    }
  } catch (e) { /* reintentar */ }

  setTimeout(() => pollForResult(cmdId, card, attempts + 1), 2000);
}

// ── Agent heartbeat: marcar si el agente está activo ──────
function startAgentHeartbeat() {
  // Hacemos polling al /api/commands/history;
  // si hay un comando que pasó de pending a done recientemente,
  // el agente está vivo.
  setInterval(async () => {
    try {
      const res  = await api.get('/api/commands/history?limit=5');
      const list = await res.json();
      const recent = list.find(e => e.completedAt &&
        Date.now() - new Date(e.completedAt).getTime() < 15_000);

      if (recent) {
        agentLastSeen = Date.now();
      }

      const alive = agentLastSeen && Date.now() - agentLastSeen < 30_000;
      agentBadge.className = `status-badge${alive ? ' active' : ''}`;
      agentText.textContent = alive ? 'ACTIVO' : 'ESPERANDO';
    } catch(e) {}
  }, 5000);
}

// ── UI: crear card de comando ─────────────────────────────
function createCard(type, arg) {
  const card = document.createElement('div');
  card.className = 'entry';

  const now = new Date().toLocaleTimeString('es', { hour12: false });

  card.innerHTML = `
    <div class="entry-head">
      <span class="entry-prompt">android@remote:~$</span>
      <span class="entry-cmd-text">
        ${esc(type)}<span class="arg">${arg ? ' ' + esc(arg) : ''}</span>
      </span>
      <span class="entry-time">${now}</span>
      <span class="badge badge-pending" data-badge>ENVIANDO</span>
    </div>
    <div class="entry-body is-wait" data-body>▸ conectando con el servidor…</div>
  `;

  return card;
}

function updateCardBadge(card, status) {
  const badge = card.querySelector('[data-badge]');
  if (!badge) return;
  badge.className = `badge badge-${status}`;
  badge.textContent = {
    pending: 'PENDIENTE',
    done:    'OK',
    timeout: 'TIMEOUT',
    error:   'ERROR',
  }[status] ?? status.toUpperCase();
}

function setCardWaiting(card, text) {
  const body = card.querySelector('[data-body]');
  if (!body) return;
  body.className = 'entry-body is-wait';
  body.textContent = text;
}

function setCardResult(card, status, result, type) {
  updateCardBadge(card, type === 'done' ? 'done' : type);

  const body = card.querySelector('[data-body]');
  if (!body) return;

  body.classList.remove('is-wait');

  if (type === 'error' || type === 'timeout') {
    body.className = `entry-body is-${type}`;
    body.textContent = result;
    scrollToBottom();
    return;
  }

  // Intentar JSON pretty-print
  try {
    const parsed = JSON.parse(result);
    body.className = 'entry-body is-json';
    body.innerHTML = syntaxHighlight(JSON.stringify(parsed, null, 2));
  } catch (_) {
    body.className = 'entry-body';
    body.textContent = result;
  }

  scrollToBottom();
}

// ── JSON syntax highlight ─────────────────────────────────
function syntaxHighlight(json) {
  return json
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"([^"]+)":/g, '<span class="json-key">"$1"</span>:')
    .replace(/: "([^"]*)"/g, ': <span class="json-str">"$1"</span>')
    .replace(/: (\d+\.?\d*)/g, ': <span class="json-num">$1</span>')
    .replace(/: (true|false)/g, ': <span class="json-bool">$1</span>')
    .replace(/: (null)/g, ': <span class="json-null">$1</span>');
}

// ── Cargar historial al inicio ────────────────────────────
async function loadHistory() {
  try {
    const res  = await api.get('/api/commands/history?limit=20');
    const list = await res.json();

    list.reverse().forEach(entry => {
      if (entry.status !== 'done') return; // Solo mostrar completados
      const card = createCard(entry.type, entry.arg ?? '');
      output.appendChild(card);
      setCardResult(card, entry.status, entry.result ?? '', entry.status);
    });

    if (list.length > 0) scrollToBottom();
  } catch(e) {
    console.warn('No se pudo cargar el historial:', e.message);
  }
}

// ── Limpiar pantalla ──────────────────────────────────────
function clearOutput() {
  const boot = document.getElementById('bootMsg');
  // Eliminar todas las cards pero mantener el boot message
  [...output.children].forEach(el => {
    if (el !== boot) el.remove();
  });
}

// ── Helpers ───────────────────────────────────────────────
function scrollToBottom() {
  output.scrollTo({ top: output.scrollHeight, behavior: 'smooth' });
}

function moveCursorToEnd() {
  const len = cmdInput.value.length;
  cmdInput.setSelectionRange(len, len);
}

function esc(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// ── Tiny fetch wrapper ────────────────────────────────────
const api = {
  get:  (url)       => fetch(url),
  post: (url, body) => fetch(url, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  }),
};
