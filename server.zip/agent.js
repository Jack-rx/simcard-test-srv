'use strict';

/**
 * /api/agent  — Endpoints consumidos exclusivamente por el agente Android.
 * Todas las rutas requieren autenticación con Bearer token.
 */

const router      = require('express').Router();
const { requireToken } = require('../middleware/auth');
const store       = require('../store');

// Aplicar auth a todas las rutas de este router
router.use(requireToken);

// ── GET /api/agent/poll ─────────────────────────────────
// El dispositivo consulta si hay un comando pendiente.
// Responde con el comando y lo marca como "tomado".
router.get('/poll', (req, res) => {
  const cmd = store.getPending();
  if (!cmd) return res.json({ command: null });

  store.clearPending();
  console.log(`📱 [${new Date().toLocaleTimeString()}] Dispositivo tomó: [${cmd.type}] ${cmd.arg}`);
  res.json({ command: cmd });
});

// ── POST /api/agent/result ──────────────────────────────
// El dispositivo entrega el resultado de un comando ejecutado.
router.post('/result', (req, res) => {
  const { id, result } = req.body;

  if (!id || result === undefined) {
    return res.status(400).json({ error: 'Se requieren id y result.' });
  }

  const resolved = store.resolveEntry(id, result);
  if (!resolved) {
    return res.status(404).json({ error: `Comando ${id} no encontrado.` });
  }

  console.log(`✅ [${new Date().toLocaleTimeString()}] Resultado recibido para ${id}`);
  res.json({ ok: true });
});

module.exports = router;
